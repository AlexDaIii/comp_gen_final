python3 extractData.py --X ../Data/CCLE_GlobalChromatinProfiling_20181130.csv --Y ../Data/CCLE_NP24.2009_Drug_data_2015.02.24.csv --outputY labels.csv --outputX features.csv
